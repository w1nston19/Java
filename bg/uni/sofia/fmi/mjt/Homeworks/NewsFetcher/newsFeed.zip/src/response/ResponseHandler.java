package response;

import article.Article;

import java.util.List;

public interface ResponseHandler {

    int totalResults();

    List<Article> getArticles();


}
