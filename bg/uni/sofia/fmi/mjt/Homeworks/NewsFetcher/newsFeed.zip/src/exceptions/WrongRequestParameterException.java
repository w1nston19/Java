package exceptions;

public class WrongRequestParameterException extends Exception {
    public WrongRequestParameterException(String message) {
        super(message);
    }
}
